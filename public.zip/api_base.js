// Configuration runtime de l'API (EBS)
//
// 👉 En prod (Render), mets ici ton URL Render, ex:
// window.API_BASE = 'https://ton-service.onrender.com';
//
// En local, tu peux laisser vide (""), si le front est servi par le même serveur.
// IMPORTANT: pas de scripts inline en hébergé Twitch.
window.API_BASE = window.API_BASE || '';
